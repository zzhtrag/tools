#!/bin/bash

# qr - Quick Record 快速记录工具（优化版）
# 功能：类似ls、top的Linux命令行工具，用于快速记录和检索信息
# 特点：无颜色代码，简洁输出
# 作者：小虾助手 🦐
# 创建时间：2026-04-06
# 版本：2.4.0

# 配置文件和数据文件路径
QR_DIR="$HOME/.qr"
QR_DATA_FILE="$QR_DIR/data.qr"
QR_CONFIG_FILE="$QR_DIR/config"

# 初始化函数 - 创建必要的目录和文件
init_qr() {
    if [ ! -d "$QR_DIR" ]; then
        mkdir -p "$QR_DIR"
    fi
    
    if [ ! -f "$QR_DATA_FILE" ]; then
        touch "$QR_DATA_FILE"
    fi
    
    if [ ! -f "$QR_CONFIG_FILE" ]; then
        cat > "$QR_CONFIG_FILE" << EOF
# qr 配置文件
# 数据文件路径: $QR_DATA_FILE
# 最大记录数: 1000
MAX_RECORDS=1000
EOF
    fi
}

# 显示帮助信息
show_help() {
    cat << EOF
qr - Quick Record 快速记录工具 (v2.4.0) | 作者: 小虾助手 🦐

用法: qr <命令> [参数]

支持的命令:
  add <内容>          添加一行记录，返回行ID
  grep <关键词>       查找包含关键词的记录
  f <关键词>          别名：grep（快捷输入）
  g <关键词>          别名：grep（快捷输入）
  q <关键词>          别名：grep（快捷输入）
  all [n m]           查看所有记录（可指定从ID=n开始，显示m条）
  del <参数>         删除记录（支持：单个ID、多个ID、区间）
  resort              重新排序行号ID，从1开始
  merge <文件>        合并文件：只添加当前data中不存在的内容
  help                显示此帮助信息
  clear               清空所有记录（需确认）
  export [文件]       导出数据到文件
  import <文件>       从文件导入数据
  install             安装qr工具到系统
  uninstall           卸载qr工具

------------------------------------------------
示例:
  qr add "明天记得开会"
  qr grep "开会"
  qr f "开会"          # 快捷方式
  qr g "开会"          # 快捷方式
  qr q "开会"          # 快捷方式
  qr all                # 查看所有（摘要）
  qr all 5 10          # 从ID=5开始，显示10条
  qr del 5              # 删除单个
  qr del 2,3,4          # 删除多个
  qr del 2-5            # 删除区间
  qr merge data.txt    # 合并data.txt中不存在的内容
  qr resort
EOF
}

# 添加记录
add_record() {
    if [ $# -eq 0 ]; then
        echo "错误: 请提供要添加的内容"
        echo "用法: qr add \"内容\""
        return 1
    fi
    
    local content="$*"
    
    # 生成行ID（当前最大ID+1）
    local last_id=0
    if [ -s "$QR_DATA_FILE" ]; then
        last_id=$(tail -n 1 "$QR_DATA_FILE" | cut -d'|' -f1)
    fi
    local new_id=$((last_id + 1))
    
    # 写入数据文件（格式：行号|内容）
    echo "$new_id|$content" >> "$QR_DATA_FILE"
    
    echo "ok"
    
    return 0
}

# 查找记录
grep_records() {
    if [ $# -eq 0 ]; then
        echo "错误: 请提供搜索关键词"
        echo "用法: qr grep \"关键词\""
        return 1
    fi
    
    local keyword="$*"
    local count=0
    
    echo "────────────────────────────────────────────"
    
    if [ ! -s "$QR_DATA_FILE" ]; then
        echo "暂无记录"
        echo "────────────────────────────────────────────"
        echo "total 0"
        return 0
    fi
    
    while IFS='|' read -r id content; do
        if echo "$content" | grep -q "$keyword"; then
            count=$((count + 1))
            printf "%4d | %s\n" "$id" "$content"
        fi
    done < "$QR_DATA_FILE"
    
    echo "────────────────────────────────────────────"
    echo "total ${count}"
    
    return 0
}

# 显示所有记录
show_all() {
    local start_id="$1"
    local count_limit="$2"
    local total_count=0
    local shown_count=0
    
    if [ ! -s "$QR_DATA_FILE" ]; then
        echo "total 0"
        echo "details refer to $QR_DATA_FILE"
        return 0
    fi
    
    # 统计总行数
    total_count=$(wc -l < "$QR_DATA_FILE" | tr -d ' ')
    
    # 如果指定了起始ID和数量
    if [ -n "$start_id" ] && [ -n "$count_limit" ]; then
        # 验证参数是否为数字
        if ! [[ "$start_id" =~ ^[0-9]+$ ]] || ! [[ "$count_limit" =~ ^[0-9]+$ ]]; then
            echo "错误: 参数必须是数字"
            echo "用法: qr all <起始ID> <显示数量>"
            return 1
        fi
        
        # 从指定ID开始显示指定数量
        local found_start=0
        while IFS='|' read -r id content; do
            # 如果还没找到起始ID
            if [ $found_start -eq 0 ]; then
                if [ "$id" = "$start_id" ]; then
                    found_start=1
                else
                    continue
                fi
            fi
            
            # 显示记录
            printf "%4d | %s\n" "$id" "$content"
            shown_count=$((shown_count + 1))
            
            # 达到显示数量限制
            if [ $shown_count -ge $count_limit ]; then
                break
            fi
        done < "$QR_DATA_FILE"
        
        # 如果没找到起始ID
        if [ $found_start -eq 0 ]; then
            echo "错误: 找不到 ID 为 $start_id 的记录"
            return 1
        fi
        
        echo "total ${shown_count}"
        return 0
    fi
    
    # 原有逻辑：如果没有参数，显示摘要
    # 如果总条数 <= 10，全部显示
    if [ $total_count -le 10 ]; then
        while IFS='|' read -r id content; do
            printf "%4d | %s\n" "$id" "$content"
        done < "$QR_DATA_FILE"
    else
        # 显示前5条
        local count=0
        while IFS='|' read -r id content; do
            printf "%4d | %s\n" "$id" "$content"
            count=$((count + 1))
            if [ $count -ge 5 ]; then
                break
            fi
        done < "$QR_DATA_FILE"
        
        # 显示省略号
        echo "..."
        
        # 显示最后5条（使用tail）
        tail -n 5 "$QR_DATA_FILE" | while IFS='|' read -r id content; do
            printf "%4d | %s\n" "$id" "$content"
        done
    fi
    
    # 显示总数和文件引用
    echo "total ${total_count}"
    echo "details refer to $QR_DATA_FILE"
    
    return 0
}

# 解析删除参数（支持：单个、多个、区间）
parse_delete_ids() {
    local param="$1"
    local ids_to_delete=()
    
    # 检查是否是区间（如 2-5）
    if [[ "$param" =~ ^[0-9]+-[0-9]+$ ]]; then
        local start=$(echo "$param" | cut -d'-' -f1)
        local end=$(echo "$param" | cut -d'-' -f2)
        
        for ((i=start; i<=end; i++)); do
            ids_to_delete+=("$i")
        done
    # 检查是否是多个ID（如 2,3,4）
    elif [[ "$param" =~ ^[0-9]+,[0-9,]+$ ]]; then
        IFS=',' read -ra arr <<< "$param"
        for id in "${arr[@]}"; do
            ids_to_delete+=("$id")
        done
    # 检查是否是单个ID
    elif [[ "$param" =~ ^[0-9]+$ ]]; then
        ids_to_delete+=("$param")
    else
        echo "错误: 参数格式不正确"
        echo "支持格式: qr del <ID> | qr del <ID,ID,...> | qr del <ID-ID>"
        return 1
    fi
    
    # 返回要删除的ID列表
    echo "${ids_to_delete[@]}"
}

# 删除记录
delete_record() {
    if [ $# -eq 0 ]; then
        echo "错误: 请提供要删除的行ID"
        echo "用法: qr del <ID> | qr del <ID,ID,...> | qr del <ID-ID>"
        echo "示例: qr del 5, qr del 2,3,4, qr del 2-5"
        return 1
    fi
    
    local param="$1"
    local deleted_count=0
    local temp_file=$(mktemp)
    
    # 解析要删除的ID
    local ids_to_delete=($(parse_delete_ids "$param"))
    
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # 复制所有不删除的记录到临时文件
    while IFS='|' read -r id content; do
        local should_delete=0
        
        # 检查当前ID是否在删除列表中
        for delete_id in "${ids_to_delete[@]}"; do
            if [ "$id" = "$delete_id" ]; then
                should_delete=1
                break
            fi
        done
        
        # 如果不删除，写入临时文件
        if [ $should_delete -eq 0 ]; then
            echo "$id|$content" >> "$temp_file"
        else
            deleted_count=$((deleted_count + 1))
        fi
    done < "$QR_DATA_FILE"
    
    # 如果没有删除任何记录
    if [ $deleted_count -eq 0 ]; then
        echo "错误: 没有找到要删除的记录"
        rm -f "$temp_file"
        return 1
    fi
    
    # 替换原文件
    mv "$temp_file" "$QR_DATA_FILE"
    
    echo "ok"
    
    return 0
}

# 重新排序行号ID（根据内容排序）
resort_records() {
    if [ ! -s "$QR_DATA_FILE" ]; then
        echo "暂无记录"
        return 0
    fi
    
    local temp_file=$(mktemp)
    local sorted_file=$(mktemp)
    local new_id=1
    
    # 根据内容排序（使用 | 作为分隔符，按第2列排序）
    sort -t'|' -k2 "$QR_DATA_FILE" > "$sorted_file"
    
    # 重新分配行号
    while IFS='|' read -r id content; do
        echo "$new_id|$content" >> "$temp_file"
        new_id=$((new_id + 1))
    done < "$sorted_file"
    
    # 替换原文件
    mv "$temp_file" "$QR_DATA_FILE"
    rm -f "$sorted_file"
    
    echo "ok"
    
    return 0
}

# 清空所有记录
clear_all() {
    # 确认清空
    echo "警告: 这将删除所有记录，且不可恢复！"
    read -p "确认清空所有记录？(输入'YES'确认): " confirm
    
    if [[ "$confirm" != "YES" ]]; then
        echo "清空操作已取消"
        return 0
    fi
    
    # 清空数据文件
    > "$QR_DATA_FILE"
    
    echo "ok"
    
    return 0
}

# 导出数据
export_data() {
    local export_file="$1"
    
    if [ $# -eq 0 ]; then
        export_file="qr_export_$(date '+%Y%m%d_%H%M%S').txt"
    fi
    
    if [ ! -s "$QR_DATA_FILE" ]; then
        echo "暂无数据可导出"
        return 0
    fi
    
    cp "$QR_DATA_FILE" "$export_file"
    
    echo "✓ 数据导出成功！"
    echo "  导出文件: $export_file"
    echo "  记录数: $(wc -l < "$export_file" | tr -d ' ')"
    
    return 0
}

# 导入数据
import_data() {
    if [ $# -eq 0 ]; then
        echo "错误: 请提供要导入的文件"
        echo "用法: qr import <文件>"
        return 1
    fi
    
    local import_file="$1"
    
    if [ ! -f "$import_file" ]; then
        echo "错误: 导入文件不存在"
        return 1
    fi
    
    # 获取当前最大ID
    local last_id=0
    if [ -s "$QR_DATA_FILE" ]; then
        last_id=$(tail -n 1 "$QR_DATA_FILE" | cut -d'|' -f1)
    fi
    
    # 导入数据
    local imported_count=0
    while IFS='|' read -r id content; do
        # 跳过空行
        if [ -z "$id" ]; then
            continue
        fi
        
        # 重新分配ID
        last_id=$((last_id + 1))
        echo "$last_id|$content" >> "$QR_DATA_FILE"
        imported_count=$((imported_count + 1))
    done < "$import_file"
    
    echo "✓ 数据导入成功！"
    echo "  导入文件: $import_file"
    echo "  导入记录数: $imported_count"
    
    return 0
}

# 规范化内容：截取#之前，去除首尾空格
normalize_content() {
    local content="$1"
    # 截取 # 之前的内容
    content="${content%%#*}"
    # 去除首尾空格
    content="$(echo -e "$content" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
    echo "$content"
}

# 检查文件是否符合qr data格式
# 格式: 每行是 "数字|内容"
check_qr_data_format() {
    local file="$1"
    
    # 文件不存在
    if [ ! -f "$file" ]; then
        return 1
    fi
    
    # 空文件，认为符合格式（可以导入）
    if [ ! -s "$file" ]; then
        return 0
    fi
    
    # 检查前10行格式
    local line_count=0
    while IFS= read -r line; do
        # 跳过空行
        [ -z "$line" ] && continue
        
        # 检查格式: 数字|内容
        if ! [[ "$line" =~ ^[0-9]+\| ]]; then
            return 1
        fi
        
        line_count=$((line_count + 1))
        [ $line_count -ge 10 ] && break
    done < "$file"
    
    # 所有检查的行都符合格式
    return 0
}

# 合并数据函数
merge_data() {
    if [ $# -eq 0 ]; then
        echo "错误: 请提供要合并的文件"
        echo "用法: qr merge <文件>"
        return 1
    fi
    
    local merge_file="$1"
    
    # 检查文件是否存在
    if [ ! -f "$merge_file" ]; then
        echo "错误: 文件不存在: $merge_file"
        return 1
    fi
    
    # 检查文件格式
    if ! check_qr_data_format "$merge_file"; then
        echo "错误: 文件格式不符合 qr data 格式"
        echo "要求格式: 每行是 \"数字|内容\""
        return 1
    fi
    
    # 读取当前 data 中的所有内容到内存，用于快速查找
    declare -A existing_contents
    if [ -s "$QR_DATA_FILE" ]; then
        while IFS='|' read -r id content; do
            [ -n "$content" ] && {
                local normalized=$(normalize_content "$content")
                [ -n "$normalized" ] && existing_contents["$normalized"]=1
            }
        done < "$QR_DATA_FILE"
    fi
    
    # 获取当前最大 ID
    local last_id=0
    if [ -s "$QR_DATA_FILE" ]; then
        last_id=$(tail -n 1 "$QR_DATA_FILE" | cut -d'|' -f1)
    fi
    
    # 遍历要合并的文件
    local added_count=0
    local skipped_count=0
    local total_count=0
    
    echo "开始合并文件: $(basename "$merge_file")"
    echo "────────────────────────────────────────"
    
    while IFS='|' read -r id content; do
        # 跳过空行
        [ -z "$id" ] && continue
        
        total_count=$((total_count + 1))
        
        # 规范化内容进行对比
        local normalized=$(normalize_content "$content")
        
        # 检查规范化后的内容是否已存在
        if [ -n "$normalized" ] && [ -n "${existing_contents["$normalized"]}" ]; then
            skipped_count=$((skipped_count + 1))
            continue
        fi
        
        # 添加新内容
        last_id=$((last_id + 1))
        echo "$last_id|$content" >> "$QR_DATA_FILE"
        [ -n "$normalized" ] && existing_contents["$normalized"]=1
        added_count=$((added_count + 1))
        
        echo "  + 添加: $content"
    done < "$merge_file"
    
    echo "────────────────────────────────────────"
    echo "合并完成！"
    echo "  总计: $total_count 条"
    echo "  新增: $added_count 条"
    echo "  跳过: $skipped_count 条（已存在）"
    
    return 0
}

# 安装函数
install_qr() {
    local install_dir="/usr/local/bin"
    local script_path="$install_dir/qr"
    
    # 获取脚本所在目录
    local script_dir="$(cd "$(dirname "$0")" && pwd)"
    
    echo "安装 qr 工具..."
    
    # 检查是否已安装
    if [ -f "$script_path" ]; then
        echo "qr 已安装，是否重新安装？"
        read -p "重新安装？(y/N): " confirm
        
        if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
            echo "安装取消"
            return 0
        fi
    fi
    
    # 复制脚本
    sudo cp "$0" "$script_path"
    sudo chmod +x "$script_path"
    
    # 创建数据目录
    mkdir -p "$QR_DIR"
    
    echo "✓ qr 工具安装成功！"
    echo "  安装路径: $script_path"
    echo "  数据目录: $QR_DIR"
    echo ""
    
    # 检查脚本同级目录下的txt文件
    local txt_files=()
    while IFS= read -r -d $'\0' file; do
        txt_files+=("$file")
    done < <(find "$script_dir" -maxdepth 1 -name "*.txt" -type f -print0 2>/dev/null)
    
    if [ ${#txt_files[@]} -gt 0 ]; then
        echo "发现 ${#txt_files[@]} 个 txt 文件，检查格式..."
        
        local valid_files=()
        for file in "${txt_files[@]}"; do
            if check_qr_data_format "$file"; then
                valid_files+=("$file")
                echo "  ✓ $(basename "$file") - 格式符合"
            else
                echo "  ✗ $(basename "$file") - 格式不符合"
            fi
        done
        
        # 如果有符合格式的文件，询问是否导入
        if [ ${#valid_files[@]} -gt 0 ]; then
            echo ""
            echo "找到 ${#valid_files[@]} 个符合 qr data 格式的文件："
            local i=1
            for file in "${valid_files[@]}"; do
                local record_count=$(wc -l < "$file" 2>/dev/null || echo 0)
                echo "  [$i] $(basename "$file") - $record_count 条记录"
                i=$((i + 1))
            done
            
            echo ""
            read -p "是否要导入这些文件？(y/N): " import_confirm
            
            if [[ "$import_confirm" == "y" || "$import_confirm" == "Y" ]]; then
                # 备份现有数据（如果存在）
                if [ -s "$QR_DATA_FILE" ]; then
                    local backup_file="$QR_DIR/data.qr.backup.$(date +%Y%m%d_%H%M%S)"
                    cp "$QR_DATA_FILE" "$backup_file"
                    echo "  ✓ 已备份现有数据到: $(basename "$backup_file")"
                fi
                
                # 导入文件
                for file in "${valid_files[@]}"; do
                    echo ""
                    echo "  导入 $(basename "$file")..."
                    
                    # 获取当前最大ID
                    local last_id=0
                    if [ -s "$QR_DATA_FILE" ]; then
                        last_id=$(tail -n 1 "$QR_DATA_FILE" | cut -d'|' -f1)
                    fi
                    
                    # 导入数据（全部导入，不检查重复）
                    local imported_count=0
                    while IFS='|' read -r id content; do
                        # 跳过空行
                        [ -z "$id" ] && continue
                        
                        # 重新分配ID
                        last_id=$((last_id + 1))
                        echo "$last_id|$content" >> "$QR_DATA_FILE"
                        imported_count=$((imported_count + 1))
                    done < "$file"
                    
                    echo "  ✓ 成功导入 $imported_count 条记录"
                done
                
                echo ""
                echo "✓ 数据导入完成！"
            fi
        fi
    fi
    
    echo ""
    echo "使用方法:"
    echo "  qr add \"你的内容\"    # 添加记录"
    echo "  qr grep \"关键词\"     # 搜索记录"
    echo "  qr f \"关键词\"        # 快捷搜索"
    echo "  qr all               # 显示所有记录"
    echo "  qr del 5             # 删除记录"
    echo "  qr resort            # 重新排序ID"
    echo "  qr help              # 查看帮助"
    
    return 0
}

# 卸载函数
uninstall_qr() {
    local install_dir="/usr/local/bin"
    local script_path="$install_dir/qr"
    
    echo "警告: 这将卸载 qr 工具"
    read -p "确认卸载？(y/N): " confirm
    
    if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
        echo "卸载取消"
        return 0
    fi
    
    # 删除脚本
    if [ -f "$script_path" ]; then
        sudo rm "$script_path"
        echo "✓ 已删除 $script_path"
    fi
    
    # 询问是否删除数据
    read -p "是否删除数据目录 $QR_DIR？(y/N): " delete_data
    
    if [[ "$delete_data" == "y" || "$delete_data" == "Y" ]]; then
        if [ -d "$QR_DIR" ]; then
            rm -rf "$QR_DIR"
            echo "✓ 已删除数据目录 $QR_DIR"
        fi
    else
        echo "数据目录保留在 $QR_DIR"
    fi
    
    echo "✓ qr 工具卸载完成"
    
    return 0
}

# 主函数
main() {
    # 初始化
    init_qr
    
    # 加载配置
    if [ -f "$QR_CONFIG_FILE" ]; then
        source "$QR_CONFIG_FILE"
    fi
    
    # 检查参数
    if [ $# -eq 0 ]; then
        show_help
        return 0
    fi
    
    # 解析命令
    local command="$1"
    shift
    
    # 如果是 install 命令，检查调用方式
    if [ "$command" = "install" ]; then
        local script_name="$(basename "$0")"
        if [ "$script_name" = "qr" ] && ! [ -f "/usr/local/bin/qr" ]; then
            echo "提示: qr 命令尚未安装，请使用以下方式安装："
            echo "  ./$script_name install"
            echo ""
            echo "或者如果在其他目录，请使用完整路径："
            echo "  /path/to/$script_name install"
            return 1
        fi
    fi
    
    case "$command" in
        add)
            add_record "$@"
            ;;
        grep|f|g|q)
            grep_records "$@"
            ;;
        all)
            show_all "$@"
            ;;
        del|delete|remove)
            delete_record "$@"
            ;;
        resort)
            resort_records
            ;;
        merge)
            merge_data "$@"
            ;;
        help|--help|-h)
            show_help
            ;;
        clear|clean)
            clear_all
            ;;
        export)
            export_data "$@"
            ;;
        import)
            import_data "$@"
            ;;
        install)
            install_qr
            ;;
        uninstall)
            uninstall_qr
            ;;
        *)
            echo "错误: 未知命令 '$command'"
            echo "使用 'qr help' 查看帮助信息"
            return 1
            ;;
    esac
    
    return $?
}

# 运行主函数
main "$@"
exit $?
