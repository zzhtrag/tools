# qr - Quick Record 快速记录工具

一个类似 `ls`、`top` 的 Linux 命令行工具，用于快速记录和检索信息。

### 核心功能
1. **qr add "内容"** - 添加一行记录，返回行ID
2. **qr grep "关键词"** - 查找包含关键词的记录
   - 别名：`qr f "关键词"`、`qr g "关键词"`、`qr q "关键词"`（快捷输入）
3. **qr all** - 显示所有记录
4. **qr del <行ID>** - 删除指定行ID的记录

### 扩展功能
5. **qr merge <文件>** - 合并文件：只添加当前data中不存在的内容
6. **qr help** - 显示帮助信息
7. **qr clear** - 清空所有记录（需确认）
8. **qr export [文件]** - 导出数据到文件
9. **qr import <文件>** - 从文件导入数据
10. **qr resort** - 根据内容排序并重新分配ID从1开始
11. **qr install** - 安装qr工具到系统
12. **qr uninstall** - 卸载qr工具

## 📦 安装方法

### 方法一：快速安装
```bash
# 1. 下载脚本

# 2. 添加执行权限
chmod +x qr.sh

# 3. 安装到系统（如果同级目录有符合格式的txt文件，会询问是否导入）
sudo ./qr.sh install
```

### 方法二：带数据安装
```bash
# 1. 准备好 qr 格式的数据文件（格式：ID|内容），命名为 data.txt
# 2. 将 data.txt 和 qr.sh 放在同一目录
# 3. 运行安装
sudo ./qr.sh install
# 4. 安装程序会自动检测并询问是否导入 data.txt
```

### 方法二：手动安装
```bash
# 1. 复制脚本到 /usr/local/bin
sudo cp qr.sh /usr/local/bin/qr

# 2. 添加执行权限
sudo chmod +x /usr/local/bin/qr

# 3. 创建数据目录
mkdir -p ~/.qr
```

### 方法三：直接使用（无需安装）
```bash
# 直接运行脚本
./qr.sh add "测试内容"
```

## 🎯 使用示例

### 基本使用
```bash
# 添加记录
qr add "明天上午10点开会"
# 输出: ok

qr add "记得买牛奶"
# 输出: ok

# 搜索记录（多种方式）
qr grep "开会"
qr f "开会"      # 快捷方式
qr g "开会"      # 快捷方式
qr q "开会"      # 快捷方式
# 输出: 显示包含"开会"的记录

# 显示所有记录
qr all
# 输出: 显示记录摘要（前5条+后5条）

# 显示指定范围记录
qr all 5 10
# 输出: 从ID=5开始，显示10条

# 删除记录
qr del 1
# 输出: ok
```

### 高级使用
```bash
# 导出数据
qr export my_notes.txt
# 输出: ✓ 数据导出成功！

# 导入数据（会重新分配ID，全部添加）
qr import old_notes.txt
# 输出: ✓ 数据导入成功！

# 合并数据（只添加不存在的内容）
qr merge other_notes.txt
# 输出: 显示合并统计，列出新增内容

# 清空所有记录（需确认）
qr clear
# 输出: 警告信息，需要输入YES确认

# 重新排序行号
qr resort
# 输出: ok
```

### import vs merge 区别
- **qr import**：导入所有内容，重新分配ID，适合全新导入
- **qr merge**：只导入不存在的内容，保留现有数据，适合合并多个数据源


## 📁 文件结构

```
~/.qr/
├── data.qr          # 主数据文件（格式：ID|内容）
└── config           # 配置文件
```

### 数据文件格式
```
1|明天上午10点开会
2|记得买牛奶
3|项目deadline是周五
```

## ⚙️ 配置选项

配置文件位置：`~/.qr/config`

```bash
# qr 配置文件
# 数据文件路径: ~/.qr/data.qr
MAX_RECORDS=1000          # 最大记录数
```

## 🔧 自定义设置

### 修改数据存储位置
```bash
# 编辑脚本，修改 QR_DIR 变量
QR_DIR="/path/to/your/custom/directory"
```

### 快捷命令说明
qr 工具内置了三个搜索命令的别名，无需额外配置：
- `qr f "关键词"` = `qr grep "关键词"`
- `qr g "关键词"` = `qr grep "关键词"`
- `qr q "关键词"` = `qr grep "关键词"`

### 添加别名（可选）
```bash
# 添加到 ~/.bashrc 或 ~/.zshrc
alias qr='/usr/local/bin/qr'

# 或者创建更短的别名
alias qa='qr add'
alias qs='qr all'
alias qd='qr del'
```

### 设置自动完成（bash）
```bash
# 创建自动完成脚本
_qr_complete() {
    local cur prev opts
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    opts="add grep f g q all del resort help clear export import install uninstall"
    
    if [[ ${cur} == * ]] ; then
        COMPREPLY=( $(compgen -W "${opts}" -- ${cur}) )
        return 0
    fi
}
complete -F _qr_complete qr
```

## 🐛 故障排除

### 常见问题

1. **命令找不到**
   ```bash
   # 检查是否在PATH中
   which qr
   
   # 如果不在，添加PATH
   export PATH=$PATH:/usr/local/bin
   ```

2. **权限问题**
   ```bash
   # 确保脚本有执行权限
   chmod +x /usr/local/bin/qr
   
   # 确保数据目录可写
   chmod 755 ~/.qr
   ```

3. **数据文件损坏**
   ```bash
   # 从备份恢复
   qr restore ~/.qr/backups/qr_backup_最新时间.qr
   ```

### 日志查看
```bash
# 查看操作日志
tail -f ~/.qr/qr.log
```

## 📈 性能特点

- **快速响应**：所有操作都在内存中完成，响应迅速
- **数据安全**：自动备份，防止数据丢失
- **易于扩展**：模块化设计，方便添加新功能
- **跨平台**：纯bash脚本，支持所有Linux发行版
- **零依赖**：只需要bash，无需安装其他软件包

## 🔄 更新与维护

### 更新脚本
```bash
# 下载最新版本
curl -O https://your-domain.com/qr.sh

# 重新安装
sudo ./qr.sh install
```

### 卸载工具
```bash
# 使用卸载命令
qr uninstall

# 或手动卸载
sudo rm /usr/local/bin/qr
rm -rf ~/.qr
```

## 🤝 贡献指南

欢迎提交Issue和Pull Request！

1. Fork项目
2. 创建功能分支
3. 提交更改
4. 推送到分支
5. 创建Pull Request

## 📄 许可证

MIT License

## 👨‍💻 作者

小虾助手 🦐

---

**提示**：使用 `qr help` 查看实时帮助信息，`qr version` 查看版本信息。
